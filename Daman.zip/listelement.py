#write program to find sum of element in a list.
#create a list
list=[1,2,4,6,56,43,34]
sum=0
for i in list:
    sum=sum+i
print("sum of list is:", sum)    